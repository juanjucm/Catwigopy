Created by Juan Julian Cea Moran at Universidad de Salamanca

End-Of-Degree Project. Official title: Platform for extracting preferences from a Twitter profile.